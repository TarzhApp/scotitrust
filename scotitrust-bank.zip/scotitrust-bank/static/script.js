// ================================
//  Mobile Menu Toggle
// ================================
const mobileMenuBtn = document.getElementById("mobileMenuBtn");
const mobileMenu = document.getElementById("mobileMenu");

if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener("click", () => {
        mobileMenu.classList.toggle("hidden");
    });
}

// ================================
//  Password / PIN Reveal Toggle
// ================================
const revealBtns = document.querySelectorAll(".reveal-pin");

revealBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        const input = document.getElementById(btn.dataset.target);

        if (input.type === "password") {
            input.type = "text";
            btn.innerText = "Hide";
        } else {
            input.type = "password";
            btn.innerText = "Show";
        }
    });
});

// ================================
//  Dashboard Balance Reveal
// ================================
const balanceText = document.getElementById("balanceText");
const balanceBtn = document.getElementById("balanceBtn");

if (balanceBtn && balanceText) {
    balanceBtn.addEventListener("click", () => {
        if (balanceText.classList.contains("blur-sm")) {
            balanceText.classList.remove("blur-sm");
            balanceBtn.innerText = "Hide Balance";
        } else {
            balanceText.classList.add("blur-sm");
            balanceBtn.innerText = "Show Balance";
        }
    });
}

// ================================
//  Tabs (Dashboard sections)
// ================================
const tabBtns = document.querySelectorAll("[data-tab-target]");
const tabContents = document.querySelectorAll("[data-tab-content]");

tabBtns.forEach(btn => {
    btn.addEventListener("click", () => {
        const target = document.querySelector(btn.dataset.tabTarget);

        tabContents.forEach(tc => tc.classList.add("hidden"));
        tabBtns.forEach(b => b.classList.remove("bg-blue-600", "text-white"));

        btn.classList.add("bg-blue-600", "text-white");
        target.classList.remove("hidden");
    });
});

// ================================
// Form Validation (Basic)
// ================================
document.querySelectorAll("form").forEach(form => {
    form.addEventListener("submit", (e) => {
        const requiredFields = form.querySelectorAll("[required]");
        let allGood = true;

        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                field.classList.add("border-red-500");
                allGood = false;
            } else {
                field.classList.remove("border-red-500");
            }
        });

        if (!allGood) {
            e.preventDefault();
            alert("Please fill all required fields.");
        }
    });
});

// ================================
// Auto-Fade Alerts Messages
// ================================
const alertBox = document.getElementById("alertBox");
if (alertBox) {
    setTimeout(() => {
        alertBox.classList.add("opacity-0");
        setTimeout(() => alertBox.remove(), 600);
    }, 3000);
}

// ================================
//  Transfer Amount Input Formatting
// ================================
const amountInputs = document.querySelectorAll(".amount-input");

amountInputs.forEach(input => {
    input.addEventListener("input", () => {
        input.value = input.value.replace(/[^0-9.]/g, "");
    });
});

// ================================
// Light Animation on Page Load
// ================================
window.addEventListener("load", () => {
    document.body.classList.add("fade-in");
});
