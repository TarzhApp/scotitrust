from models import connect, init_db

init_db()
db = connect()
cursor = db.cursor()

demo_users = [
    ("andrew_scot", "1234", 4500.00),
    ("marta_pl", "1234", 3100.50),
    ("keegan_mix", "1234", 2200.00)
]

for u in demo_users:
    try:
        cursor.execute("INSERT INTO users (username, password, balance) VALUES (?, ?, ?)", u)
    except:
        pass

db.commit()
db.close()

print("Demo users added.")
