from flask import Flask, render_template, request, redirect, session
from models import init_db, get_user, get_balance, make_transfer, get_transactions, get_all_users

app = Flask(__name__)
app.secret_key = "your-secret-key"

@app.route("/")
def home():
    if "user_id" in session:
        return redirect("/dashboard")
    return redirect("/login")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        user = get_user(username, password)
        if user:
            session["user_id"] = user[0]
            return redirect("/dashboard")
        else:
            return render_template("login.html", error="Invalid login")

    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect("/login")

    user_id = session["user_id"]
    balance = get_balance(user_id)
    transactions = get_transactions(user_id)

    return render_template("dashboard.html", balance=balance, transactions=transactions)

@app.route("/transfer", methods=["GET", "POST"])
def transfer():
    if "user_id" not in session:
        return redirect("/login")

    if request.method == "POST":
        sender_id = session["user_id"]
        receiver_username = request.form["receiver"]
        amount = float(request.form["amount"])

        result = make_transfer(sender_id, receiver_username, amount)
        return render_template("transfer.html", message=result)

    return render_template("transfer.html")

@app.route("/admin")
def admin():
    users = get_all_users()
    return render_template("admin.html", users=users)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000)
