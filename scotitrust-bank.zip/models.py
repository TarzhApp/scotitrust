import sqlite3
from datetime import datetime

DB_NAME = "bank.db"

def connect():
    return sqlite3.connect(DB_NAME, check_same_thread=False)

def init_db():
    db = connect()
    cursor = db.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY,
        username TEXT UNIQUE,
        password TEXT,
        balance REAL
    )
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY,
        sender_id INTEGER,
        receiver_id INTEGER,
        amount REAL,
        timestamp TEXT
    )
    """)

    db.commit()

def get_user(username, password):
    db = connect()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
    return cursor.fetchone()

def get_balance(user_id):
    db = connect()
    cursor = db.cursor()
    cursor.execute("SELECT balance FROM users WHERE id=?", (user_id,))
    result = cursor.fetchone()
    return result[0] if result else 0

def get_all_users():
    db = connect()
    cursor = db.cursor()
    cursor.execute("SELECT id, username, balance FROM users")
    return cursor.fetchall()

def get_transactions(user_id):
    db = connect()
    cursor = db.cursor()
    cursor.execute("""
        SELECT sender_id, receiver_id, amount, timestamp
        FROM transactions
        WHERE sender_id=? OR receiver_id=?
        ORDER BY id DESC
    """, (user_id, user_id))
    return cursor.fetchall()

def make_transfer(sender_id, receiver_username, amount):
    db = connect()
    cursor = db.cursor()

    cursor.execute("SELECT id FROM users WHERE username=?", (receiver_username,))
    receiver = cursor.fetchone()

    if not receiver:
        return "Receiver not found."

    receiver_id = receiver[0]

    cursor.execute("SELECT balance FROM users WHERE id=?", (sender_id,))
    sender_balance = cursor.fetchone()[0]

    if sender_balance < amount:
        return "Insufficient balance."

    cursor.execute("UPDATE users SET balance = balance - ? WHERE id=?", (amount, sender_id))
    cursor.execute("UPDATE users SET balance = balance + ? WHERE id=?", (amount, receiver_id))

    cursor.execute("""
        INSERT INTO transactions (sender_id, receiver_id, amount, timestamp)
        VALUES (?, ?, ?, ?)
    """, (sender_id, receiver_id, amount, datetime.now().isoformat()))

    db.commit()
    return "Transfer successful."
